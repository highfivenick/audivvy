// config/database.js
module.exports = {

    'url' : 'mongodb+srv://highfive_nick:nick@cluster0.tqbln.mongodb.net/projects?retryWrites=true&w=majority', 
    'dbName': 'projects'
};
